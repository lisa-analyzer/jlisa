package com.example.spring.security;

import java.security.Principal;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class ApiController {

	@GetMapping("/me")
	public Map<String, String> me(Principal principal) {
		return Map.of("name", principal.getName());
	}

}
