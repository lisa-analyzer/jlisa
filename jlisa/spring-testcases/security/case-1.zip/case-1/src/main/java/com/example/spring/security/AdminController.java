package com.example.spring.security;

import java.lang.management.ManagementFactory;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/admin")
public class AdminController {

	@GetMapping("/stats")
	public Map<String, Long> stats() {
		return Map.of("uptimeMs", ManagementFactory.getRuntimeMXBean().getUptime());
	}

}
