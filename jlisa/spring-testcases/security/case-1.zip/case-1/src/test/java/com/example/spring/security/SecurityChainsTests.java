package com.example.spring.security;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.security.web.FilterChainProxy;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
class BuSecurityChainsTests {

	@Autowired
	MockMvc mvc;

	@Autowired
	FilterChainProxy springSecurityFilterChain;

	@Test
	void onlyTheTwoDeclaredChainsExist() {
		assertThat(springSecurityFilterChain.getFilterChains()).hasSize(2);
	}

	@Test
	void publicLetsAnyoneIn() throws Exception {
		mvc.perform(get("/public/hello")).andExpect(status().isOk());
		mvc.perform(get("/public/hello").with(httpBasic("user", "wrong"))).andExpect(status().isOk());
	}

	@Test
	void apiRequiresLogin() throws Exception {
		mvc.perform(get("/api/me")).andExpect(status().isUnauthorized());
		mvc.perform(get("/api/me").with(httpBasic("user", "password")))
			.andExpect(status().isOk())
			.andExpect(jsonPath("$.name").value("user"));
	}

	@Test
	void adminRejectsAnonymous() throws Exception {
		mvc.perform(get("/admin/stats")).andExpect(status().isUnauthorized());
	}

	@Test
	void adminRejectsUser() throws Exception {
		mvc.perform(get("/admin/stats").with(httpBasic("user", "password"))).andExpect(status().isForbidden());
	}

	@Test
	void adminLetsAdminIn() throws Exception {
		mvc.perform(get("/admin/stats").with(httpBasic("admin", "password"))).andExpect(status().isOk());
	}

	@Test
	void otherPathsRequireLogin() throws Exception {
		mvc.perform(get("/other")).andExpect(status().isUnauthorized());
		mvc.perform(get("/other").with(httpBasic("user", "password"))).andExpect(status().isNotFound());
	}

}
