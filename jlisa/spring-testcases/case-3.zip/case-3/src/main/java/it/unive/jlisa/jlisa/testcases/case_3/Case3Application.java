package it.unive.jlisa.jlisa.testcases.case_3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Case3Application {

	public static void main(String[] args) {
		SpringApplication.run(Case3Application.class, args);
	}

}
