package it.unive.jlisa.jlisa.testcases.case_3.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PublicLayer {

    @GetMapping(value = "/public/info")
    public String info() {
        return "info";
    }

    @PostMapping(value = "/public/feedback")
    public String submitFeedback() {
        return "thanks";
    }
}
