package it.unive.jlisa.jlisa.testcases.case_3.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;

@Controller
public class ClientLayer {

    @GetMapping(value = "/client/status")
    public String status() {
        return "ok";
    }

    @PatchMapping(value = "/client/profile")
    public String patchProfile() {
        return "patched";
    }
}
