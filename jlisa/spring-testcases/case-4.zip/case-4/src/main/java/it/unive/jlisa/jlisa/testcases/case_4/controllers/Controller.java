package it.unive.jlisa.jlisa.testcases.case_4.controllers;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path = { "/api", "/api/legacy" }, produces = MediaType.TEXT_PLAIN_VALUE,
        consumes = { MediaType.APPLICATION_JSON_VALUE, "text/*" }, params = "!disabled", headers = "!X-Blocked",
        version = "1.0+")
public class Controller {

    @GetMapping(value = "/hello-world")
    public String endpoint1() {
        return "Hello World!";
    }

    @PostMapping(path = "/greet", consumes = MediaType.APPLICATION_JSON_VALUE)
    public String endpoint2() {
        return "Greeted!";
    }

    @PutMapping("/update")
    public String endpoint3() {
        return "Updated!";
    }

    @DeleteMapping({ "/delete", "/remove" })
    public String endpoint4() {
        return "Deleted!";
    }

    @PatchMapping(value = "/patch", consumes = "application/json", produces = "application/json")
    public String endpoint5() {
        return "{\"patched\": true}";
    }

    @RequestMapping(value = { "/any", "/all" }, method = { RequestMethod.GET, RequestMethod.POST })
    public String endpoint6() {
        return "Any!";
    }

    @GetMapping(path = "/versioned", version = "1.0")
    public String endpoint7() {
        return "Version 1.0";
    }

    @GetMapping(path = "/versioned", version = "2.0+")
    public String endpoint8() {
        return "Version 2.0 or later";
    }

    @GetMapping(path = "/search", params = { "q", "lang=en", "!debug" })
    public String endpoint9() {
        return "Searched!";
    }

    @PostMapping(path = "/secure", headers = { "X-Api-Key", "X-Client=web" })
    public String endpoint10() {
        return "Secured!";
    }

    @RequestMapping(path = { "/filter", "/filter/all" }, method = RequestMethod.GET, params = "type", headers = "Accept-Language=it")
    public String endpoint11() {
        return "Filtered!";
    }

    @RequestMapping("/everything")
    public String endpoint12() {
        return "Every method!";
    }

    @GetMapping("/items/{id}")
    public String endpoint13(@PathVariable String id) {
        return "Item " + id;
    }

    @GetMapping({ "/users/{name:[a-z]+}", "/files/**" })
    public String endpoint14() {
        return "Pattern matched!";
    }

    @PostMapping(path = "/upload", consumes = { "!text/plain", "text/*" }, headers = "!X-Debug")
    public String endpoint15() {
        return "Uploaded!";
    }

    @GetMapping
    public String endpoint16() {
        return "Root!";
    }

    @RequestMapping(path = "/options", method = RequestMethod.OPTIONS)
    public String endpoint17() {
        return "Options!";
    }

    @RequestMapping(path = "/head", method = RequestMethod.HEAD)
    public String endpoint18() {
        return "Head!";
    }

    @RequestMapping(path = "/trace", method = RequestMethod.TRACE)
    public String endpoint19() {
        return "Trace!";
    }

    public String endpoint20() {
        return "No method!";
    }

    @RequestMapping
    public String endpoint21() {
        return "Bare mapping!";
    }

    public String endpoint22() {
        return "Again no method!";
    }
}
