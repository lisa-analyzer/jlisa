package it.unive.jlisa.jlisa.testcases.case_1.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {

    @GetMapping(value = "/hello-world")
    public String endpoint1() {
        return "Hello World!";
    }
}