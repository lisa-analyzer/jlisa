package it.unive.jlisa.jlisa.testcases.case_5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Case5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
