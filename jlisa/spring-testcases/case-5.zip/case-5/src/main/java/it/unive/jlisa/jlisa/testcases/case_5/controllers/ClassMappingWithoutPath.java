package it.unive.jlisa.jlisa.testcases.case_5.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(produces = "text/plain")
public class ClassMappingWithoutPath {

    @GetMapping
    public String root() {
        return "root";
    }
}
