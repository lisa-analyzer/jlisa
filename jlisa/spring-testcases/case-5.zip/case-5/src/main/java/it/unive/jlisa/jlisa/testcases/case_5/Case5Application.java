package it.unive.jlisa.jlisa.testcases.case_5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Case5Application {

	public static void main(String[] args) {
		SpringApplication.run(Case5Application.class, args);
	}

}
