package it.unive.jlisa.jlisa.testcases.case_5.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class NoClassMapping {

    @GetMapping
    public String root() {
        return "root";
    }

    @PostMapping("")
    public String emptyPath() {
        return "empty";
    }
}
