package it.unive.jlisa.jlisa.testcases.case_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Case1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
