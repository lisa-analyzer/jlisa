package it.unive.jlisa.jlisa.testcases.case_2.controllers;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {

    @GetMapping(value = "/users")
    public String listUsers() {
        return "users";
    }

    @PostMapping(value = "/users")
    public String createUser() {
        return "created";
    }

    @PutMapping(path = "/users/{id}")
    public String updateUser() {
        return "updated";
    }

    @DeleteMapping(value = "/users/{id}")
    public String deleteUser() {
        return "deleted";
    }
}
